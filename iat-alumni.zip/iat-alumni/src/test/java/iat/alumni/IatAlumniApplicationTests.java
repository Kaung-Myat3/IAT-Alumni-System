package iat.alumni;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IatAlumniApplicationTests {

	@Test
	void contextLoads() {
	}

}
