package iat.alumni.service;

import iat.alumni.model.Student;

public interface StudentService {
	Student authenrticate(String iatEmail);
}