package iat.alumni.service;

import iat.alumni.model.UserRole;

public interface UserRoleService {
	void saveUserRole(UserRole userRole);
}